This project does not have a description yet.
To add it, edit the `README.md` file located in the project directory.


# How to Edit

To open this description in the editor,
click the *Edit description* button on the toolbar to the top right.
Also you can:

* Click this link: [README.md](./README.md).
* Double-click the `README.md` file in the *Project* pane to the left.
* Select *Edit description* from the menu on the *Project* pane.

# Text Markup

pSeven uses
[CommonMark](https://commonmark.org/help/)
as the default text markup language.
It is a simple markup designed for easy editing.
CommonMark is enabled in
project and workflow descriptions, workflow annotations,
port and parameter descriptions, and other texts in pSeven.

Below you can find the basic set of CommonMark,
which in most cases is enough to create well-described projects.


## Paragraphs

To start a new paragraph, use a blank line.
A single line break does not produce a new paragraph:

    The first statement in a paragraph.
    The second statement in the same paragraph.
    
    The new paragraph.

Other text blocks (lists, tables) and headers should also be separated with blank lines.

## Headers

Use one or more `#` characters to make headers:

    # Header Level 1
    
    ## Header Level 2
    
    ### Header Level 3
    
    #### Header Level 4
    
    ##### Header Level 5
    
    ###### Header Level 6

## Emphasis

Use asterisks `*` or underscores `_` for emphasis:

    *italics* or _italics_
    
    **bold** or __bold__

## Lists

Unordered and ordered lists are made as follows:

    1. First ordered list item.
    2. Another item.
      * Unordered sub-list.
    1. Actual numbers do not matter, just start items with any number and a dot.
      1. Ordered sub-list.
    4. And another item.

## Tables

Use HTML to insert tables:

    <table>
      <tr>
        <td>Column 1</td>  <td>Column 2</td>
      </tr><tr>
        <td>11</td>        <td>12</td>
      </tr><tr>
        <td>12</td>        <td>22</td>
      </tr>
    </table>

## Links

Link syntax is `[link text](link path)`, where `link text` is the displayed text,
and `link path` can be:

* A path to some external resource: `[DATADVANCE website](https://www.datadvance.net/)`.
* A page in the pSeven User Manual: `[pSeven Help](?/doc/index.html)`.
* A file in the project (the dot in the path represents the project directory):
  * `[My workflow](./workflow_name.p7wf)`,
  * `[My report](./report_name.p7rep)`,
  * `[sample data](./samples/sample.csv)`.

When you click a link to a file which pSeven can edit
(for example, a workflow or a report), this file opens in pSeven.
Otherwise, for file types which pSeven does not support,
the linked file opens in the default system application for this file type.

## Images

Image syntax is `![alt text](image location)` -
note that it starts with `![` to distinguish images from links.
The `image location` can be:

* An image URL from the web: `![web image](http://www.server.com/image.jpeg)`.
* A path to an image located inside the project directory: `[project image](./README.png)`.
  The leading dot in the path represents the project directory.

The `alt text` is optional and can be empty: `[](./README.png)`.
It is the text displayed instead of the actual image in cases when the image file cannot be loaded.

# Math

You can add formulas to project and workflow descriptions using the TeX syntax:
enclose your formula in `$​$ ... $​$`.
For example:

    $​$\int_0^2{xdx}$​$

Rendered, this code becomes:

$$\int_0^2{xdx}$$

Math rendering is handled by [KaTeX](https://katex.org/) which supports a subset of TeX functions -
see [Supported Functions](https://katex.org/docs/supported.html) for details.

# Usage

For examples of using the markup described above,
see descriptions of pSeven example projects.
You can browse the examples on the *Workspace* screen:
switch to the *Welcome* tab and click *Examples*.
When you open an example, pSeven shows its description automatically.

For more information about how to create a project and start working with it, see
[Tutorial Project](?/doc/tutorials/project.html) in the pSeven User Manual.

For full details on the supported markup, see the
[CommonMark Spec](https://spec.commonmark.org/current/)
and
[KaTeX's Supported Functions](https://katex.org/docs/supported.html).
