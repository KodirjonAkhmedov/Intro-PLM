from amewrapper import Amewrapper
import numpy as np
import math
import sys
import json
import time

def run_workflow(path_to_base, fuel_stack_power, battery_capacity):
    filepath_no_ext = path_to_base+'Amesim_models/Energy/Energy_model'
    aw = Amewrapper(filepath_no_ext)
    aw.save_as('Energy_model_1',path_to_base+'Project_folder/')

    # Set parameters

    #set path to power profile
    aw.set_parameter('filename@dynamic_time_table', path_to_base+'Project_folder/power_profile.dat')
    # set number of fuel cells in parallel
    number_of_fuel_cells = math.ceil(float(fuel_stack_power)/26)
    aw.set_global_parameter('Ncell', number_of_fuel_cells)
    # set number of batteries cells in parallel
    bat_in_par = math.ceil(float(battery_capacity/(4*2.3)))
    aw.set_parameter('np@BatPackGene', bat_in_par)


    # aw.set_parameter('filenameCt@component_5.aero_fd_prop','test/string.dat')
    # aw.set_parameter('mass@mass_friction_endstops',333)
    # aw.set_global_parameter('Tinit',22)

    # Set run parameters: duration and timestep
    simulation_time = 10
    aw.set_run_params(simulation_time,0.5)

    # Run simulation
    #time.sleep(5)
    aw.run_simulation()

    # fuel mass
    fuel_mass_arr = aw.get_result_value('output@tank')
    # battery charge
    state_of_charge = aw.get_result_value('soc@BatPackGene')

    # Save and exit
    aw.save_file()

    # RESULTS

    #batteries mass
    number_of_cells_in_series = 4
    batteries_mass = number_of_cells_in_series * bat_in_par * 0.07

    # fuel mass
    # fuel_mass_arr = aw.get_result_value('output@tank')
    fuel_mass_arr = np.array(fuel_mass_arr)
    fuel_mass = fuel_mass_arr[-1][1]

    # fuel tank mass
    fuel_tank_mass = (24.7*fuel_mass*1000+180)*0.001

    # fuel stack mass
    fuel_stack_mass = number_of_fuel_cells * 0.025

    status = 1
    #state_of_charge = aw.get_result_value('soc@BatPackGene')
    state_of_charge = np.array(state_of_charge)
    if state_of_charge[-1][1] < simulation_time:
        status = 0

    energy_results = {
        'batteries_mass':batteries_mass,
        'fuel_mass': fuel_mass,
        'fuel_stack_mass': fuel_stack_mass,
        'fuel_tank_mass': fuel_tank_mass,
        'status': status,
    }
    with open(path_to_base+'Project_folder/energy_result.txt', 'w') as j:
       j.write(json.dumps(energy_results))

    #Success/Fail
    # if the difference between required and real trajectory less than 5 m along all trajectory: success = 1
    #file = open(r"..../Project_folder/simulation_result.txt", "w")
    #with open(status_path, 'w') as j:
    #    j.write(json.dumps(status))




if __name__ == "__main__":
    # local_settings_path = sys.argv[1]
    # local_pp = sys.argv[2]

    #input mission base and mission path
    #path_to_base = 'D:/Optimization2/'
    path_to_base = sys.argv[1]


    #input fuel_stack_power
    #fuel_stack_power = 2000
    fuel_stack_power = float(sys.argv[2])

    #input batteries
    #battery_capacity = 100
    battery_capacity = float(sys.argv[3])

    run_workflow(path_to_base, fuel_stack_power, battery_capacity)
    exit(0)