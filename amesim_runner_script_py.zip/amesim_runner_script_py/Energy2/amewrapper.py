import os
import sys
sys.path.append(os.environ['AME']+"/scripting/python/")
sys.path.append(os.environ['AME']+"/scripting/python/win64/")
import subprocess
from amesim import *
from ame_apy import *

class Amewrapper:

    def __init__(self, filepath_no_ext):
        self._filepath = filepath_no_ext+'.ame'
        self._filepath_no_ext = filepath_no_ext
        if not os.path.isfile(self._filepath):
            raise Exception('.ame file not exist')
        AMEInitAPI(False)
        AMEOpenAmeFile(self._filepath)
    
    def save_file(self):
        AMECloseCircuit(True)
        AMECloseAPI()

    def save_as(self,filename,dir_path):
        AMESaveCircuitAs(filename, dir_path, True)

    def set_parameter(self,param_path,param_value):
        AMESetParameterValue(param_path, str(param_value))

    def set_run_params(self, duration, timestep):
        AMESetRunParameter('stop_time_s', str(duration))
        AMESetRunParameter('interval_s', str(timestep))

    def set_global_parameter(self,param_name,param_value):
        AMESetGlobalParameterValue(param_name, str(param_value))

    def get_global_parameter(self,param_name):
        return AMEGetGlobalParameterValue(param_name)

    def run_simulation(self):
        AMEGenerateCode()
        AMERunSimulation()

    def get_result_value(self,result_path):
        return AMEGetVariableValues(result_path)
