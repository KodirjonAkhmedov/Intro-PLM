from amewrapper import Amewrapper
import numpy as np
import json
import sys

def run_workflow(total_mass, path_to_base, path_to_mission):
    filepath_no_ext = path_to_base+'Amesim_models/Flight/Flight_12arms'
    aw = Amewrapper(filepath_no_ext)
    aw.save_as('flight_12arms_1',path_to_base+'Project_folder/')

    # Set parameters
    #set path to mission
    aw.set_global_parameter('Path_to_Mission',path_to_base+path_to_mission)
    aw.set_global_parameter('Path_to_Cpmap',path_to_base+'Amesim_models/Flight/Flight_12arms_data/Cpmap.data')
    aw.set_global_parameter('Path_to_Ctmap',path_to_base+'Amesim_models/Flight/Flight_12arms_data/Ctmap.data')

    #set total mass
    aw.set_parameter('mass@aero_fd_6dof_body',total_mass)

    # Set run parameters: duration and timestep
    aw.set_run_params(10, 0.5)

    # Run simulation
    aw.run_simulation()

    # RESULTS

    #Power profile
    power_profile = aw.get_result_value('output@dynamic_gen_addition')


    #Success/Fail
    # if the difference between required and real trajectory less than 5 m along all trajectory: success = 1

    status = 1
    trajectory_difference = aw.get_result_value('output@component_2_1.subtraction')

    # Save and exit
    aw.save_file()

    power_profile = np.array(power_profile)
    file = open(path_to_base + 'Project_folder/power_profile.dat', "w")
    file.write('#	Table format: 1D\n')
    file.write('	' + str(0) + '	' + str(0) + '\n')
    for i in range(0, len(power_profile) - 1):
        file.write('	' + str(power_profile[i + 1][0]) + '	' + str(power_profile[i + 1][1]) + '\n')
    file.close()

    trajectory_difference = np.array(trajectory_difference)
    for i in range(0, len(trajectory_difference)-1):
        if trajectory_difference[i][1] > 5:
            status = 0

    propulsion_results = {
        'status': status
    }
    with open(path_to_base + 'Project_folder/propulsion_result.txt', 'w') as j:
        j.write(json.dumps(propulsion_results))

    #print('RESULT: '+res2[0])

    # Save and exit

if __name__ == "__main__":

    #input mission base and mission path
    #path_to_base = 'D:/Optimization1/'
    path_to_base = sys.argv[1]

    #path_to_mission = 'Missions/mission3.data'
    path_to_mission = sys.argv[2]

    #input total mass
    #total_mass = 20
    total_mass = float(sys.argv[3])

    run_workflow(total_mass, path_to_base, path_to_mission)