from amewrapper import Amewrapper
import numpy as np
import math
import sys
import json

def run_workflow(path_to_base, fuel_stack_power, battery_capacity):
    filepath_no_ext = path_to_base+'Amesim_models/Energy3/Energy_model3'
    aw = Amewrapper(filepath_no_ext)
    aw.save_as('Energy_model_3_1',path_to_base+'Project_folder/')

    # Set parameters

    #set path to power profile
    aw.set_parameter('filename@dynamic_time_table', path_to_base+'Project_folder/power_profile.dat')
    # set number of fuel cells in parallel
    number_of_fuel_cells = math.ceil(float(fuel_stack_power)/22)
    aw.set_global_parameter('Ncell', number_of_fuel_cells)
    # set number of batteries cells in parallel
    bat_in_par = battery_capacity/(4*2.3)
    aw.set_parameter('np@BatPackGene', bat_in_par)

    # Set run parameters: duration and timestep
    simulation_time = 10
    aw.set_run_params(simulation_time,0.5)

    # Run simulation
    aw.run_simulation()

    # RESULTS

    #batteries mass
    number_of_cells_in_series = 4
    batteries_mass = number_of_cells_in_series * bat_in_par * 0.07

    # fuel mass
    fuel_mass_arr = aw.get_result_value('output@stack.elect02_1')
    fuel_mass_arr = np.array(fuel_mass_arr)
    fuel_mass = fuel_mass_arr[-1][1]
    fuel_volume = fuel_mass/0.40625 #in Liters

    # fuel tank mass
    fuel_tank_mass = fuel_volume * 0.24 #kg

    # fuel stack mass
    fuel_stack_mass = number_of_fuel_cells * 0.02

    # state of charge
    status = 1
    state_of_charge = aw.get_result_value('soc@BatPackGene')
    state_of_charge = np.array(state_of_charge)
    for i in range(0, len(state_of_charge)):
        if state_of_charge[i][1] < 10:
            status = 0

    energy_results = {
        'batteries_mass':batteries_mass,
        'fuel_mass': fuel_mass,
        'fuel_stack_mass': fuel_stack_mass,
        'fuel_tank_mass': fuel_tank_mass,
        'status': status
    }
    with open(path_to_base+'Project_folder/energy_result.txt', 'w') as j:
       j.write(json.dumps(energy_results))

    # Save and exit
    aw.save_file()

if __name__ == "__main__":

    #input mission base and mission path
    path_to_base = 'D:/Optimization3/'
    #path_to_base = sys.argv[1]

    #input fuel_stack_power
    fuel_stack_power = 2000
    #fuel_stack_power = float(sys.argv[2])

    #input batteries
    battery_capacity = 100
    #battery_capacity = float(sys.argv[3])

    run_workflow(path_to_base, fuel_stack_power, battery_capacity)
    